#include "peça.h"

int main()
{
	srand(time(NULL));
	char strInput[100];
	char nomeFicheiro[20];
	int nProcessos = 0;
	int tempoME = 0;
	int n = 0;
	int m = 0;
	int maxComprimento = 0;
	int *compPecas = malloc(sizeof(int) * 10);
	int *qttdPecas = malloc(sizeof(int) * 10);

	//getFileCommand(nomeFicheiro, strInput, &nProcessos, &tempoME);
	strcpy(nomeFicheiro, "prob03.txt");
	nProcessos = 10;
	tempoME = 3;
	printf("\nNome do ficheiro: %s\n", nomeFicheiro);
	printf("Numero de processos: %d\n", nProcessos);
	printf("Tempo maximo de execução: %d\n", tempoME);

	readFile(&n, &m, &maxComprimento, compPecas, qttdPecas, nomeFicheiro);
	printf("\nN: %d\n", n);
	printf("M: %d\n", m);
	printf("MaxComprimento: %d\n", maxComprimento);
	printf("compPecas: ");
	for(int j=0; j<m; j++) {
		printf("%d ", compPecas[j]);
	}
	printf("\n");
	printf("qttdPecas: ");
	for(int j=0; j<m; j++) {
		printf("%d ", qttdPecas[j]);
	}
	printf("\n");
	
	//Criação da matriz e do sol (memoria partilhada)
	int protection = PROT_READ | PROT_WRITE;
	int visibility = MAP_ANONYMOUS | MAP_SHARED;
	int (*matrix)[m+2] = (int (*)[m+2]) mmap(NULL, n*m*sizeof(int), protection, visibility, 0, 0);
	int *sol = mmap(NULL, m*sizeof(int), protection, visibility, 0, 0);
	signal(SIGUSR1, signal_handler);
	signal(SIGUSR2, signal_handler2);

	do{
		createMatrix(n, m, matrix, maxComprimento, compPecas);
		createSol(n, m, sol, qttdPecas, matrix);
	}while(!isSolValid(sol, qttdPecas, n, m, matrix));

	printf("Vetor Inicial\n");
	printSol(m, sol);
	printf("Matriz Inicial\n");
	printMatrix(n, m, matrix);
	int wasteInicial = getWaste(sol, n, m, matrix, qttdPecas, compPecas, maxComprimento);
	printf("\nWaste inicial: %d\n", wasteInicial);
	int *iter = mmap(NULL, sizeof(int), protection, visibility, 0, 0);
	*iter = 0;
	
	//Processos
	sem_unlink("mymutex");
	sem_t *job = sem_open("mymutex", O_CREAT, 0644, 1);
	int pids[nProcessos];
	struct timeval start_time;
  	gettimeofday(&start_time, NULL);
	for(int i=0; i < nProcessos; i++) {
		
		pids[i] = fork();
		if (pids[i] == 0) {

			while(1) {
				work(m, n, nProcessos, matrix, compPecas, qttdPecas, maxComprimento, sol, job, i, nomeFicheiro, *iter, start_time);
				*iter = *iter + 1;

			}
			
			//exit(0);
		}
	}

	killProcesses(nProcessos, tempoME, pids);

	int wasteFinal = getWaste(sol, n, m, matrix, qttdPecas, compPecas, maxComprimento);
	int avaliation = wasteFinal;
	for(int i = 0; i<m;i++)
		avaliation += sol[i];
	printf("\nMatriz Final\n");
	printMatrix(n, m, matrix);
	printf("Vetor Final\n");
	printSol(m, sol);
	printf("Numero do teste: \n");
	printf("Nome do teste: \n");
	printf("Tempo maximo de execução: %d\n", tempoME);
	printf("Numero de processos usado: %d\n", nProcessos);
	printf("Waste final: %d\n", wasteFinal);
	printf("Iterações: %d\n", *iter);
	printf("Tempo a atingir a melhor solução:\n");
	printf("Avaliação: %d\n", avaliation);
	sem_close(job);
	/*a) Número do teste (de 1 a 10).
	b) Nome do teste.
	**c) Tempo total de execução.
	**d) Número de processos usado (parâmetro p na descrição dos algoritmos).
	**e) Vetores solução encontrados, valor total do comprimento das peças por cortar em metros para
	cada solução do vetor, e valor total do desperdício em metros para cada solução do vetor.
	**f) Número de iterações necessárias para chegar ao melhor vetor solução encontrado.
	g) Tempo que demorou até o programa atingir o melhor vetor solução encontrado*/
	free(compPecas);
	free(qttdPecas);
	return EXIT_SUCCESS;	
}
