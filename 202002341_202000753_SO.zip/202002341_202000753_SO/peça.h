#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <sys/mman.h>
#include <signal.h>
#include <string.h>
#include <semaphore.h>
#include <sys/time.h>
#include <time.h>
#include <fcntl.h>

void getFileCommand(char *nomeFicheiro, char *strInput, int *nProcessos, int *tempoME);
void readFile(int *n, int *m, int *maxComprimento, int *compPecas, int *qttdPecas, char *nomeFicheiro);
void createMatrix(int n, int m, int matrix[n][m], int maxComprimento, int *compPecas);
void printMatrix(int n, int m, int matrix[n][m]);
bool isMatrixValid(int n, int m, int matrix[n][m]);
int calculateSumLine(int n, int m, int matrix[n][m], int line);
int calculateSumCol(int n, int m, int matrix[n][m], int col);
void createSol(int n, int m, int *sol, int *qttdPecas, int matrix[n][m]);
void printSol(int m, int *sol);
void killProcesses(int nProcessos, int tempoME, int pids[nProcessos]);
void work(int m, int n, int nProcessos, int matrix[n][m], int *compPecas, int *qttdPecas, int maxComprimento, int *sol, sem_t *job, int ii, char problem[], int iterations, struct timeval start_time);
void createVetor(int m, int *vetor, int r);
bool isSolValid(int *sol, int *qttdPecas, int n, int m, int matrix[n][m]);
int getWaste(int *vectSol, int n, int m, int matrix[n][m], int *qttdPecas, int *compPecas, int maxComprimento);
void signal_handler(int signal);
void signal_handler2(int signal);
float time_diff(struct timeval *start, struct timeval *end);