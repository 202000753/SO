#include "peça.h"
#include <time.h>

void getFileCommand(char *nomeFicheiro, char *strInput, int *nProcessos, int *tempoME)
{
	printf("(nome do ficheiro) (numero de processos) (tempo maximo de execução)> ");
	fgets(strInput, 20, stdin);

	//Dividir o comando recebido pelos campos
	char *ptr = strtok(strInput, " ");
	if(ptr != NULL) {
		strcpy(nomeFicheiro, ptr);
		ptr = strtok(NULL, " ");
	}
	if(ptr != NULL) {
		*nProcessos = atoi(ptr);
		ptr = strtok(NULL, " ");
	}
	if(ptr != NULL) {
		*tempoME = atoi(ptr);
		ptr = strtok(NULL, " ");
	}
}

void readFile(int *n, int *m, int *maxComprimento, int *compPecas, int *qttdPecas, char *nomeFicheiro)
{
    FILE *file  = fopen(nomeFicheiro, "r");

	if (file == NULL) 
	{   
		printf("Error! Could not open file\n"); 
		exit(-1);
	} 

	fscanf(file, "%d", n);  
	fscanf(file, "%d", m);  
	fscanf(file, "%d", maxComprimento);  
	for(int i=0; i < *m; i++) {
		fscanf(file, "%d", &compPecas[i]);  
	}
	printf("\n");
	for(int i=0; i < *m; i++) {
		fscanf(file, "%d", &qttdPecas[i]);  
	}	
}

void createMatrix(int n, int m, int matrix[n][m], int maxComprimento, int *compPecas)
{
	for(int i=0; i<n; i++) {
		for(int j=0; j<m; j++) {
			matrix[j][i] = 0;
		}
	}

	int comprimentoDisponivel = 0;
	/*do {
		for(int i=0; i<n; i++) {
		comprimentoDisponivel = maxComprimento;
			do{
				for(int j=0; j<m; j++) {
					//do{
						int d = 0, r = 0;
						//printf("%d%d\n", i, j);
						if(comprimentoDisponivel > 0) {
							//printf("cD %d\n", comprimentoDisponivel);
							//printf("cP %d\n", compPecas[j]);
							d = comprimentoDisponivel/compPecas[j];
							//printf("d %d\n", d);
							if(d > 0)
							{
								r = rand() % d;
								//printf("r %d\n", r);
								matrix[j][i] = r;
							}
							else
								matrix[j][i] = 0;
							//printf("m %d\n", matrix[j][i]);
							//printf("m*cP %d\n", matrix[j][i] * compPecas[j]);
							comprimentoDisponivel -= matrix[j][i] * compPecas[j];
							//printf("cD %d\n", comprimentoDisponivel);
						}
						else
							matrix[j][i] = 0;
						//printf("\n");
					//}while(calculateSumLine(n, m, matrix, j) == 0);
				}
			}while(calculateSumCol(n, m, matrix, i) == 0);
		}
		sleep(2);
		printf("\n\n\n");
		printMatrix(n, m, matrix);
	}while(!isMatrixValid(n, m, matrix));*/

	for(int i=0; i<n; i++) {
		comprimentoDisponivel = maxComprimento;
		
		do{
			for(int j=0; j<m; j++) {
				int d = 0;

				if(comprimentoDisponivel > 0) {
					d = comprimentoDisponivel/compPecas[i];
					matrix[j][i] = rand() % d;
					comprimentoDisponivel -= matrix[j][i] * compPecas[i];
				}
				else
					matrix[j][i] = 0;
			}
		}while(calculateSumCol(n, m, matrix, i) == 0);
	}
	
	//printMatrix(n, m, matrix);
}

void printMatrix(int n, int m, int matrix[n][m])
{
	for(int i=0; i<n; i++)
	{	    	
		for(int j=0; j<m; j++)
		{
			if(j == 0)
				printf("[");
			printf("%d",matrix[i][j]);

			if(j != m-1)
				printf(", ");

			if(j == m-1)
				printf("]");
		}

		printf("\n");
	}
}

bool isMatrixValid(int n, int m, int matrix[n][m])
{
	int sumCol = 0, sumLine = 0;
	for(int i=0; i<n; i++) {
		if(calculateSumCol(n, m, matrix, i) > 0)
			sumCol++;
	}
	for(int i=0; i<m; i++) {
		if(calculateSumLine(n, m, matrix, i) > 0)
			sumLine++;
	}

	printf("l %d, c %d\n", sumCol, sumLine);

	if(sumCol == n && sumLine == m)
		return true;

	return false;
}

int calculateSumLine(int n, int m, int matrix[n][m], int line)
{
	int sum = 0;
	for(int i=0; i<n; i++) {
		sum += matrix[line][i];
	}

	return sum;
}

int calculateSumCol(int n, int m, int matrix[n][m], int col)
{
	int sum = 0;
	for(int i=0; i<m; i++) {
		sum += matrix[i][col];
	}

	return sum;
}

void createSol(int n, int m, int *sol, int *qttdPecas, int matrix[n][m])
{
	for(int i = 0; i<m; i++)
	{
		sol[i] = 0;
	}
	
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j<m; j++)
		{
			float sum = (float)qttdPecas[j] / (float)matrix[j][i];
			int sum2 = (int) sum;
			if(sol[i] < sum2)
				sol[i] = sum2;
		}
	}
	
}

void printSol(int m, int *sol)
{
	for(int i=0; i<m; i++)
	{
		if(i == 0)
			printf("[");

	    	printf("%d",sol[i]);

		if(i != m-1)
			printf(", ");

		if(i == m-1)
			printf("]\n");
	}
}

void killProcesses(int nProcessos, int tempoME, int pids[nProcessos])
{
	sleep(tempoME);
	
	for (int i=0; i<nProcessos; i++) {
		//printf("Killing %d\n", pids[i]);
		kill(pids[i], SIGKILL);
	}
}

void work(int m, int n, int nProcessos, int matrix[n][m], int *compPecas, int *qttdPecas, int maxComprimento, int *sol, sem_t *job, int ii, char problem[], int iterations, struct timeval start_time)
{	
	int matrixProcess[m][n];
	int percentagem = rand() % 10;
	int vetor[m];
	int sum = 0;
	int wasteVetor = 0, wasteSol = 0;
	wasteSol = getWaste(sol, n, m, matrixProcess, qttdPecas, compPecas, maxComprimento);
	struct timeval inicial_time;
  	gettimeofday(&inicial_time, NULL);
	
	for(int i=0; i<n; i++) {
		for(int j=0; j<m; j++) {
			matrixProcess[j][i] = matrix[j][i];
		}
	}
	
	for(int i = 0; i< m; i++)
	{
		vetor[i] = sol[i];
	}
	
	sem_wait(job);
	if(percentagem <= 7)
	{
		int r = 0;
		r = rand() % m;
		do
		{
			
			createVetor(m, vetor, r);
		
		}while(!isSolValid(vetor, qttdPecas, n, m, matrixProcess));
		
		wasteVetor = getWaste(vetor, n, m, matrixProcess, qttdPecas, compPecas, maxComprimento);
		
		if(wasteVetor < wasteSol)
		{
			//Envia sinal ao pai
			kill(getppid(), SIGUSR1);
			//sem_wait(job);
			//printf("Better\n");
			for(int i = 0; i< m; i++)
			{
				sol[i] = vetor[i];
			}
	
			//sem_post(job);
		}
		
	}
	sem_post(job);
	//20% das vezes
	sem_wait(job);
	if(percentagem > 7)
	{
		int vetorSubstitui[m];
		do
		{
			createMatrix(n, m, matrixProcess, maxComprimento, compPecas);
			createSol(n, m, vetorSubstitui, qttdPecas, matrix);
		}while(!isSolValid(vetorSubstitui, qttdPecas, n, m, matrixProcess));
		
		wasteVetor = getWaste(vetorSubstitui, n, m, matrixProcess, qttdPecas, compPecas, maxComprimento);
	
		
		if(wasteVetor < wasteSol)
		{
			//Envia sinal ao pai
			kill(getppid(), SIGUSR1);
			//sem_wait(job);
			//printf("Better\n");
			for(int i = 0; i< m; i++)
			{
				sol[i] = vetorSubstitui[i];
			}


			//printf("Change Matrix\n");
			for(int i=0; i<n; i++) 
			{
				for(int j=0; j<m; j++) 
				{
					matrix[j][i] = matrixProcess[j][i];
				}
			}

			//sem_post(job);
		}	
		//printMatrix(n, m, matrixProcess);
	}

	int eval = 30;
	struct timeval current_time;
  	gettimeofday(&current_time, NULL);
	char delim[] = ".";
	char *ptr = strtok(problem, delim);

	printf("%s%3s%8s%5s%8s%9s%13s%7s%10s\n", "i", "n", "problem", "m", "ttime", "eval", "iterations", "time", "objects");
	printf("%d%3d%7s%6d%8.3f%7d%8d %f%10s", ii, n, ptr, m, time_diff(&start_time, &current_time), eval, iterations+1, time_diff(&inicial_time, &current_time), "");
	printSol(m, sol);
	printf("Matrix:\n");
	printMatrix(n, m, matrix);
	printf("Solution:\n");
	printSol(m, sol);
	printf("Min sum(sol) = %d Wastage = %d Avaliation = %d\n\n\n", 18, getWaste(vetor, n, m, matrixProcess, qttdPecas, compPecas, maxComprimento), 30);

	sem_post(job);
}

void createVetor(int m, int *vetor, int r)
{
	vetor[r];
	vetor[r] = rand() % 30;
}

bool isSolValid(int *sol, int *qttdPecas, int n, int m, int matrix[n][m])
{
	bool valid = true;
	int colRes = 0;

	for(int i = 0; i < m; i++)
	{
		colRes = 0;

		for(int j = 0; j < n; j++)
		{
		    	colRes += matrix[i][j] * sol[j];
		}

		if(colRes < qttdPecas[i])
		{
		    valid = false;
		}
	}

	return valid;
}

int getWaste(int *vectSol, int n, int m, int matrix[n][m], int *qttdPecas, int *compPecas, int maxComprimento)
{
	int waste = 0, waste1 = 0, waste2 = 0, maxColResComp = 0;

	for(int i = 0; i<n; i++)
	{
		int colRes = 0;

		for(int j = 0; j < m; j++)
		{
			colRes += (matrix[j][i] * compPecas[j]);
		}

		maxColResComp = (maxComprimento - colRes);

		if(maxColResComp > 0)
			waste1 += maxColResComp;	
	}
	
	
	for(int i=0; i<n; i++)
	{
		int colRes = 0;

		for(int j=0; j<m; j++)
		{
			colRes += (matrix[i][j]*vectSol[j]);
		}
		
		colRes -= qttdPecas[i];
		
		waste2 += colRes;
		colRes = 0;
	}
	waste = waste1 + waste2;
	return waste;
}

void signal_handler(int signal)
{
	//sleep(1.5);
	//printf("Parent: Handling process with PID=%d\n", getpid());
	//kill(pids[i], SIGUSR2);
}

void signal_handler2(int signal)
{
	//printf("Child: Handled, PID=%d\n", getpid());
}

float time_diff(struct timeval *start, struct timeval *end)
{
    return (end->tv_sec - start->tv_sec) + 1e-6*(end->tv_usec - start->tv_usec);
}